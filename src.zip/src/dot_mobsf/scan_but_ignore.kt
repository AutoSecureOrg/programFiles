 private fun showN(show: Boolean) {
     
            xyz.visibility = if (show) View.GONE else View.VISIBLE
            xyz.animate()
            
}

Log.e("foo", foo.toString())



android.secret_key="supersecret key" // mobsf-ignore: android_kotlin_hardcoded