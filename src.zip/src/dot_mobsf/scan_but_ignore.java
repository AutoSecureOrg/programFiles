HttpClient client = new DefaultHttpClient();

String password = "strong password"; // mobsf-ignore: hardcoded_password