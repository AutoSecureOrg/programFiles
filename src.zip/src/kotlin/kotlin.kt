 private fun showN(show: Boolean) {
     
            xyz.visibility = if (show) View.GONE else View.VISIBLE
            xyz.animate()
            
}

Log.e("foo", foo.toString())

